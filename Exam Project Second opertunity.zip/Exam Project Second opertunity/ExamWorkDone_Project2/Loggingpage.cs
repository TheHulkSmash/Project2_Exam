﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
namespace ExamWorkDone_Project2
{
    public partial class Loggingpage : Form
    {
        public Loggingpage()
        {
            InitializeComponent();
        }

        private static readonly Object obj = new Object();

        private void button1_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = textBox1.Text;
            pass = textBox2.Text;

            bool lockWasTaken = false;
            var temp = obj;
            try
            {
                Monitor.Enter(temp, ref lockWasTaken);

                if (user == "admin" && pass == "admin")
                {
                    MessageBox.Show("You are logged in.");
                    this.Hide();
                }
                else if (user == "Reinard" && pass == "Waterberg2020")
                {
                    MessageBox.Show("You are logged in.");
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error. Wrong credentials.");
                }
            }
            finally
            {
                if (lockWasTaken)
                {
                    Monitor.Exit(temp);
                }
            }
        }

        private void Loggingpage_Load(object sender, EventArgs e)
        {

        }
    }
}
